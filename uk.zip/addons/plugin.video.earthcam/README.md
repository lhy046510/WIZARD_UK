# plugin.video.earthcam plugin for XBMC

EarthCam.com is the premiere network of scenic webcams and offers a complete database of interesting places and views from around the world. EarthCam.com is the worlds favorite webcam network and the EarthCam Network cameras have been seen on top news shows, including CNN Headline News.

v1.0.7 was broken, so I forked this one to fix it.

### Fork

forked [from](http://addons.tvaddons.ag/show/plugin.video.earthcam/) official-xbmc-hub-repo [v1.0.7](https://github.com/idleloop-github/xbmc-earthcam/tree/3e263215a4a3ea9ccba0092bf097939f8b25ff58)

### Changes

* v1.0.7 was broken, fixed.
* more cams available
* readable cam descriptions (with "Media Info" Confluence View, for example)
* better still previews if available (showed as background with Confluence)
* compatible with previous plugin versions "XBMC favourites" - the reverse could not be true

### Installation

* [download zip](https://github.com/idleloop-github/xbmc-earthcam/archive/master.zip)
* XBMC: System / Add-ons / Install from zip file / select this zip

If skilled, previous to installation, rename the directory contained in the zip from "xbmc-earthcam-master" to "plugin.video.earthcam", and the zip to "plugin.video.earthcam-1.0.7.1.zip" in order to do a *perfect* installation.

### License

Distributed [under GPL 3](http://www.gnu.org/licenses/gpl-3.0.html)

### Contact

[idleloop](http://www.angelfire.com/ego2/idleloop/) -at- yahoo.com   
BTC: 1GX726he5TNgnDuG4qG9zrM6CSN7uyga6F