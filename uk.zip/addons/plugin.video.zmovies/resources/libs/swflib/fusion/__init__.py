"""
Mecheye Fusion, a SWF creator/parser in pure Python.
"""
