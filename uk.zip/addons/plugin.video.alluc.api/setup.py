#!/usr/bin/python
#Alluc
'''
    Copyright (C) 2015 DudeHere

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

############################
### Imports		 		 ###
############################
import os
import sys
import xbmc
import xbmcaddon
sys.path.append(os.path.join(xbmc.translatePath( "special://home/addons/script.module.pyxbmct/" ), 'lib'))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))
from commonlib import *
import pyxbmct.addonwindow as pyxbmct


class WindowClass(pyxbmct.AddonDialogWindow):

	def __init__(self, title=''):
		super(WindowClass, self).__init__(title)
		self.setGeometry(700, 300, 6, 3)
		self.set_info_controls()
		self.set_active_controls()
		self.set_navigation()
		self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
		
	def setAnimation(self, control):
		control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])
	def set_info_controls(self):
		heading = pyxbmct.Label('Welcome to Alluc!')
		self.placeControl(heading, 0, 0)
		
		userLabel = pyxbmct.Label('Trakt Username:')
		self.placeControl(userLabel, 1, 0)
		self.userField = pyxbmct.Edit('')
		self.placeControl(self.userField, 1, 1)
		self.userField.setText(ADDON.get_setting('trakt-username'))
	
		passLabel = pyxbmct.Label('Trakt Password:')
		self.placeControl(passLabel, 2, 0)
		self.passField = pyxbmct.Edit('')
		self.placeControl(self.passField, 2, 1)
		self.passField.setText(ADDON.get_setting('trakt-password'))
	
		allucUserLabel = pyxbmct.Label('Alluc Username:')
		self.placeControl(allucUserLabel, 3, 0)
		self.AllucUserField = pyxbmct.Edit('')
		self.placeControl(self.AllucUserField, 3, 1)
		self.AllucUserField.setText(ADDON.get_setting('alluc-username'))
		
		passLabel = pyxbmct.Label('Alluc Password:')
		self.placeControl(passLabel, 4, 0)
		self.AllucPassField = pyxbmct.Edit('')
		self.placeControl(self.AllucPassField, 4, 1)
		self.AllucPassField.setText(ADDON.get_setting('alluc-password'))


	def set_active_controls(self):
		self.saveButton = pyxbmct.Button('Save')
		self.placeControl(self.saveButton, 5, 1)
		# Connect control to close the window.
		self.connect(self.saveButton, self.save_event)

	def set_navigation(self):
		self.userField.controlDown(self.passField)
		self.passField.controlDown(self.AllucUserField)
		self.AllucUserField.controlDown(self.AllucPassField)
		self.AllucPassField.controlDown(self.saveButton)
		
		
		self.passField.controlUp(self.userField)
		self.AllucUserField.controlUp(self.passField)
		self.AllucPassField.controlUp(self.AllucUserField)
		self.saveButton.controlUp(self.AllucPassField)
		
		self.setFocus(self.userField)
	def save_event(self):
		ADDON.set_setting('trakt-username', self.userField.getText())
		ADDON.set_setting('trakt-password', self.passField.getText())
		ADDON.set_setting('alluc-username', self.AllucUserField.getText())
		ADDON.set_setting('alluc-password', self.AllucPassField.getText())
		ADDON.set_setting('setup_run', "true")
		from alluc_api import AllucAPI
		AllucAPI()._get_api_key()
		ADDON.log('Save Accounts')
		self.close()

def import_keyfile():
	import xbmcgui, xbmcvfs
	path = xbmcgui.Dialog().browse(1, 'Select a keyfile', "files", "", False )
	fh = xbmcvfs.File(path, 'r')
	content=fh.read().strip()
	fh.close()
	dialog = xbmcgui.Dialog()
	print len(content)
	if len(content)==32:
		if dialog.yesno("Update your API Key", "Do you wish to proceed?", content):
			ADDON.set_setting('alluc-private-key', content)

def color_picker(type):
	import xbmcgui, xbmcvfs
	fh = xbmcvfs.File(ROOT_PATH + '/resources/colors.txt', 'r')
	content=fh.read().strip()
	fh.close()
	colors = content.splitlines()
	dialog = xbmcgui.Dialog()
	display = []
	for color in colors:
		color = color.lower()
		display.append("[COLOR %s]%s[/COLOR]" % (color, color))
	choice = dialog.select('Select a color', display)
	if choice < 0:
		return False
	color = colors[choice].lower()
	ADDON.set_setting('custom_color_' + type, color)

args = ADDON.parse_query(sys.argv[2])
print args
if args['mode'] == 		'main':
	window = WindowClass('Alluc Setup - Please Enter Account Info!')
	window.doModal()
	del window
elif args['mode'] == 		'import_keyfile':
	import_keyfile()
elif args['mode'] == 		'color_picker':
	color_picker(args['type'])