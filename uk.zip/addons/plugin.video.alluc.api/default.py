#!/usr/bin/python
#Alluc
'''
    Copyright (C) 2015 DudeHere

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

############################
### Imports		 		 ###
############################	

import urllib2
import urllib
import sys
import os
import re
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import unicodedata
import string
from BeautifulSoup import BeautifulSoup, Tag, NavigableString
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))
import hashlib
try: 
	import simplejson as json
except ImportError: 
	import json
from urllib import quote_plus
from addon.common.net import Net
from metahandler import metahandlers
from commonlib import *
from functions import *
net = Net()
vfs = Vfs()

############################
### Enviornment		 	 ###
############################
ART_PATH = ROOT_PATH + '/resources/artwork'
FANART = vfs.join(ROOT_PATH, 'fanart.jpg')
ICON = vfs.join(ROOT_PATH, 'icon.png')
hash_id = None
BASE_URL = ADDON.get_setting('alluc-url')
if not vfs.exists("special://userdata/addon_data/%s" % ADDON_ID):
	vfs.mkdir("special://userdata/addon_data/%s" % ADDON_ID)
if ADDON.get_bool_setting('movie_custom_directory'):
	MOVIE_DIRECTORY = ADDON.get_setting('movie_directory')
else:
	MOVIE_DIRECTORY = "special://userdata/addon_data/%s/movies" % ADDON_ID
if ADDON.get_bool_setting('tv_show_custom_directory'):
	TVSHOW_DIRECTORY = ADDON.get_setting('tv_show_directory')
else:
	TVSHOW_DIRECTORY = "special://userdata/addon_data/%s/tvshows" % ADDON_ID
	
BASE_URL = ADDON.get_setting('alluc-url')
if ADDON.get_setting('alluc-auth-method') == 'Password':
	APIKEY = None
else:
	APIKEY=ADDON.get_setting('alluc-private-key')
if ADDON.get_setting('cache-search-results')=='true':
	CACHE_RESULTS = True
else :
	CACHE_RESULTS = False
if ADDON.get_setting('filter-results')=='true':
	FILTER_RESULTS = True
else:
	FILTER_RESULTS = False
if ADDON.get_setting('use-metadata')=='true':
	USE_METADATA=True
else:
	USE_METADATA=False
if ADDON.get_setting('sort-results')=='true':
	SORT_BY_HOST = True
else:
	SORT_BY_HOST = False
if ADDON.get_setting('enable-filter-lang')=='true':
	table = ["en","fr","es","de","it","he"]
	FILTER_LANG = table[int(ADDON.get_setting('filter-lang'))]
else:
	FILTER_LANG = False
ENABLED_COLOR = ADDON.get_setting('custom_color_enabled')
SIZE_COLOR = ADDON.get_setting('custom_color_size')
HOST_COLOR = ADDON.get_setting('custom_color_host')
EXTENSION_COLOR = ADDON.get_setting('custom_color_ext')
NUMBER_THREADS = int(ADDON.get_setting('use-threadpool'))
MAX_RESULTS = int(ADDON.get_setting('max-results'))
############################
### Database		     ###
############################
IGNORE_UNIQUE_ERRORS = True
if ADDON.get_setting('database_mysql')=='true':
	DB_NAME = ADDON.get_setting('database_mysql_name')
	DB_USER = ADDON.get_setting('database_mysql_user')
	DB_PASS = ADDON.get_setting('database_mysql_pass')
	DB_PORT = ADDON.get_setting('database_mysql_port')
	DB_ADDRESS = ADDON.get_setting('database_mysql_host')
	DB_TYPE = 'mysql'
	from database import MySQLDatabase
	DB=MySQLDatabase(DB_ADDRESS, DB_NAME, DB_USER, DB_PASS, DB_PORT)
else:
	from database import SQLiteDatabase
	DB_TYPE = 'sqlite'
	DB_FILE = xbmc.translatePath(ADDON.get_setting('database_sqlite_file'))
	DB=SQLiteDatabase(DB_FILE)

############################
### Menu Stuff		     ###
############################
	
class ContextMenu:
	def __init__(self):
		self.commands = []

	def add(self, text, arguments={}):
		cmd = self._build(arguments)
		self.commands.append((text, cmd, ''))
	
	def _build(self, arguments):
		cmd = 'XBMC.RunPlugin(%s?' % sys.argv[0]
		for key, item in arguments.items():
			if item: item = urllib.quote_plus(item.encode('utf-8'))
			cmd = "%s&%s=%s" %(cmd, urllib.quote_plus(str(key)), item)
		cmd = cmd + ')'
		return cmd

	def get(self):
		self.add(get_str(30720), {"mode": "tv_watchlist"})
		self.add(get_str(30721), {"mode": "movie_watchlist"})
		return self.commands
			
def setView(view, content=None, viewid=None):
	if ADDON.get_setting('enable-default-views') == 'true':
		if content:
			xbmcplugin.setContent(int(sys.argv[1]), content)
		if not viewid:
			viewid = ADDON.get_setting(view)
		xbmc.executebuiltin("Container.SetViewMode(%s)" % viewid)
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
		xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )

def EOD(view='default-folder-view', content=None, viewid=None):
	if view=='custom':
		setView('custom', content=content, viewid=viewid)
	else:
		setView(view,content=content)
	ADDON.end_of_directory()

def MENU_ITEM(data, info, image=None, fanart=None, menu=None, isPlayable=False):
	if not vfs.exists(fanart): 
		fanart=FANART
	if not vfs.exists(image): 
		image=ICON
	if not menu:
		menu=ContextMenu()
	if isPlayable: 
		isFolder = False
	else:
		isFolder = True
	ADDON.add_directory(data, info, img=image, fanart=fanart, contextmenu_items=menu.get(), is_folder=isFolder)

def clean_file_name(filename):
	filename = unicode(filename)
	validFilenameChars = "-_.() %s%s" % (string.ascii_letters, string.digits)
	cleanedFilename = unicodedata.normalize('NFKD', filename).encode('ASCII', 'ignore')
	return ''.join(c for c in cleanedFilename if c in validFilenameChars)

def log(msg):
	print str(msg).encode("utf8")

def readfile(path, soup=False):
	try:
		file = vfs.open(path, 'r')
		content=file.read()
		file.close()
		if soup:
			soup = BeautifulSoup(content)
			return soup
		else:
			return content
	except IOError, e:
		log(e, level=1, error=True)
		return ''

def writefile(path, content):
	try:
		file = vfs.open(path, 'w')
		file.write(content)
		file.close()
		return True
	except IOError, e:
		log(e, level=1, error=True)
		return False
class ProgressClass(xbmcgui.DialogProgress):
	def __init__(self, *args, **kwargs):
		xbmcgui.DialogProgress.__init__(self, *args, **kwargs)
		self._silent = False
		self._index = 0
		self._total = 0
		self._percent = 0
	def new(self, heading, total):
		if not self._silent:
			self._index = 0
			self._total = total
			self._percent = 0
			self._heading = heading
			self.create(heading)
			self.update(0, heading, '')
	def next(self, subheading):
		if not self._silent:
			self._index = self._index + 1
			self._percent = self._index * 100 / self._total
			PB.update(self._percent, self._heading, subheading)

PB = ProgressClass()
############################
### Main Functions		 ###
############################

def SetupLibrary(quite=False):
	source_path = vfs.join('special://profile/', 'sources.xml')
	try:
		soup = readfile(source_path, soup=True)
	except:
		soup = BeautifulSoup()
		sources_tag = Tag(soup, "sources")
		soup.insert(0, sources_tag)
		
	if soup.find("video") == None:
		sources = soup.find("sources")
		video_tag = Tag(soup, "video")
		sources.insert(0, video_tag)
		
	video = soup.find("video")
	if len(soup.findAll(text="Movies (%s)" % ADDON_NAME)) < 1:
		movie_source_tag = Tag(soup, "source")
		movie_name_tag = Tag(soup, "name")
		movie_name_tag.insert(0, "Movies (%s)" % ADDON_NAME)
		MOVIES_PATH_tag = Tag(soup, "path")
		MOVIES_PATH_tag['pathversion'] = 1
		MOVIES_PATH_tag.insert(0, MOVIE_DIRECTORY)
		movie_source_tag.insert(0, movie_name_tag)
		movie_source_tag.insert(1, MOVIES_PATH_tag)
		video.insert(2, movie_source_tag)

	if len(soup.findAll(text="TV Shows (%s)" % ADDON_NAME)) < 1:	
		tvshow_source_tag = Tag(soup, "source")
		tvshow_name_tag = Tag(soup, "name")
		tvshow_name_tag.insert(0, "TV Shows (%s)" % ADDON_NAME)
		tvshow_path_tag = Tag(soup, "path")
		tvshow_path_tag['pathversion'] = 1
		tvshow_path_tag.insert(0, TVSHOW_DIRECTORY)
		tvshow_source_tag.insert(0, tvshow_name_tag)
		tvshow_source_tag.insert(1, tvshow_path_tag)
		video.insert(2, tvshow_source_tag)
	string = ""
	for i in soup:
		string = string + str(i)
	writefile(source_path, str(soup))
	if not quite:
		dialog = xbmcgui.Dialog()
		dialog.ok("Source folders added", "To complete the setup:", " 1) [B]Restart XBMC.[/B]", " 2) Set the content type of added folders.")

def Autoupdate(media, quite=False):
	ADDON.log( "Update: " + media)
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	if media=='TV':
		shows = DB.query("SELECT imdb_id, title FROM subscriptions WHERE enabled=1", force_double_array=True)
		for show in shows:
			UpdateSubscription(show[0])
			xbmc.sleep(50)
		lists = DB.query("SELECT media, username, slug, id FROM lists WHERE media='tvshow' AND sync=1", force_double_array=True)
		for li in lists:
			shows = trakt.get_custom_list(li[2], li[0], username=li[1])
			for show in shows:
				UpdateSubscription(show['imdb_id'])
				xbmc.sleep(50)
		if ADDON.get_setting('update_library')=='true':
			xbmc.executebuiltin('UpdateLibrary(video,' + TVSHOW_DIRECTORY + ')')			
	elif media=='LIBRARY':
		xbmc.executebuiltin('UpdateLibrary(video,' + TVSHOW_DIRECTORY + ')')
		xbmc.executebuiltin('UpdateLibrary(video,' + MOVIE_DIRECTORY + ')')
	else:
		lists = DB.query("SELECT media, username, slug, id FROM lists WHERE media='movie' AND sync=1", force_double_array=True)
		for li in lists:
			movies = trakt.get_custom_list(li[2], li[0], username=li[1])
			DB.execute("DELETE FROM list_movies WHERE list_id=?", [li[3]])
			for movie in movies:
				AddMovieToLibrary(movie['imdb_id'], list_id=li[3])
				xbmc.sleep(50)
			DB.commit()
		if ADDON.get_setting('update_library')=='true':
				xbmc.executebuiltin('UpdateLibrary(video,' + MOVIE_DIRECTORY + ')')

def UpdateSubscription(imdb_id):
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	show = trakt.get_show_info(imdb_id, False)
	series = clean_file_name(show['title'])
	show_path = vfs.join(TVSHOW_DIRECTORY, series, preserve=True)
	vfs.mkdir(show_path, recursive=True)
	show = trakt.get_show_info(imdb_id, True)
	for row in show:
		if 'episodes' in row.keys():
			season = row['episodes'][0]['season']
			if season > 0:
				season_path = vfs.join(show_path, "Season %s" % season, preserve=True)
				vfs.mkdir(season_path)
				for ep in row['episodes']:
					doit = True
					if ADDON.get_setting('import_aired_only')=='true':
						doit = check_air_date(ep['first_aired'])
					if doit:
						episode = ep['number']
						filename = "%s S%sE%s.strm" % (series, str(season).zfill(2), str(episode).zfill(2))
						full_path =  vfs.join(season_path, filename, preserve=True)
						params = {"mode": "watch_stream", "media": "episode", "imdb_id": imdb_id, "season":season, "episode": episode, "trakt": ep['ids']['trakt'], "file": full_path}
						url = "plugin://%s/?%s" % (ADDON_ID, urllib.urlencode(params))
						create_str_file(full_path, url)

def create_str_file(full_path, url):
	create_file = True
	if ADDON.get_setting('overwrite_strm_files')=='false':
		if vfs.exists(full_path):
			create_file = False
	if create_file:
		file = vfs.open(full_path,'w')
		file.write(url)
		file.close()

def check_air_date(aired):
	if aired:
		from datetime import date
		now = date.today()
		match = re.search('^(.+?)-(.+?)-(.+?)T', aired)
		y = int(match.group(1))
		m = int(match.group(2))
		d = int(match.group(3))
		aired = date(y,m,d)
		if aired < now:
			return True
		else: 
			return False
		
def ToggleWatchedState():
	if args['media']=='episode':
		metadata ={"media": args['media'], "title": args['title'], "imdb_id": args['imdb'], "season": args['season'], "episode": args['episode'], "year": ''}
	if args['mode']=='mark_watched':
		SetPlayCount(metadata, 1)
	else:
		SetPlayCount(metadata, 0)

def SetPlayCount(metadata, playcount):
	mark = playcount + 6
	ADDON.log('Mark it %s' % mark)
	try:
		MH = metahandlers.MetaData()
		MH.change_watched(metadata['media'], metadata['title'], metadata['imdb_id'], season=metadata['season'], episode=metadata['episode'], year=metadata['year'], watched=mark)
	except:
		pass
	#try:
	if metadata['media'] == 'episode':
		if 'show' in metadata.keys():
			show_title = metadata['show']
		else:
			show_title = metadata['title']
		jsonrpc =  json.dumps({ "jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": { "filter": {"and": [
		{"field": "tvshow", "operator": "is", "value": show_title}, 
		{"field": "season", "operator": "is", "value": str(metadata["season"])}, 
		{"field": "episode", "operator": "is", "value": str(metadata["episode"])}
		]}}, "id": 1 })
		response = json.loads(xbmc.executeJSONRPC(jsonrpc))
		ADDON.log(response)
		if 'episodes' in response['result'].keys():
			episodeid = response['result']['episodes'][0]['episodeid']
			jsonrpc = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.SetEpisodeDetails", "params": {"episodeid" : int(episodeid), "playcount": playcount}})
			response = xbmc.executeJSONRPC(jsonrpc)
			ADDON.log(response)
	else:
		jsonrpc =  json.dumps({ "jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": { "filter": {"and": [
		{"field": "title", "operator": "is", "value": metadata['title']},
		{"field": "year", "operator": "is", "value": str(metadata['year'])}
		]}}, "id": 1 })
		response = json.loads(xbmc.executeJSONRPC(jsonrpc))
		ADDON.log(response)
		if 'movies' in response['result'].keys():
			movieid = response['result']['movies'][0]['movieid']
			jsonrpc = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.SetMovieDetails", "params": {"movieid" : movieid, "playcount": playcount}})
			response = xbmc.executeJSONRPC(jsonrpc)
			ADDON.log(response)
	#except:
	#	pass
	REFRESH()
	
def SyncList(title, username, slug, media):
	DB.execute("INSERT INTO lists(list, username, slug, media) VALUES(?,?,?,?)", [title, username, slug, media])
	DB.commit()
	Notify("List sync:", title)
	REFRESH()
	
def UnSyncList(title, username, slug):
	dialog = xbmcgui.Dialog()
	if dialog.yesno("UnSync", "Do you want to unsync %s?" % title):
		DB.execute("UPDATE lists SET sync=0 WHERE slug=? AND username=?", [slug, username])
		DB.commit()
		Notify("Sync deleted:", title)
		REFRESH()

def Subscribe(imdb_id, title):
	ADDON.log("Subscribe " + imdb_id)
	DB.execute("INSERT INTO subscriptions(imdb_id, title) VALUES(?,?)", [imdb_id, title])
	DB.commit()
	UpdateSubscription(imdb_id)
	Notify("Subscribe to:", title)
	
def Unsubscribe(imdb_id, title):
	ADDON.log("Unsubscribe " + imdb_id)
	dialog = xbmcgui.Dialog()
	if dialog.yesno("Unsubscribe", "Do you want to remove %s?" % title):
		DB.execute("DELETE FROM subscriptions WHERE imdb_id=?", [imdb_id])
		DB.commit()
		series = clean_file_name(title)
		show_path = vfs.join(TVSHOW_DIRECTORY, series)
		vfs.rm(show_path, recursive=True)
		REFRESH()
		Notify("Subscription deleted:", title)

def AddMovieToLibrary(imdb_id, list_id=False):
	#ADDON.log("Import movie " + imdb_id)
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	movie = trakt.get_movie_info(imdb_id)
	movie_title = clean_file_name(movie['title'])
	movie_path = vfs.join(MOVIE_DIRECTORY, movie_title, preserve=True)
	vfs.mkdir(movie_path, recursive=True)
	filename = "%s.strm" % movie_title
	full_path =  vfs.join(movie_path, filename, preserve=True)
	params = {"mode": "watch_stream", "media": "movie", "imdb_id": imdb_id, "file": full_path}
	url = "plugin://%s/?%s" % (ADDON_ID, urllib.urlencode(params))
	create_str_file(full_path, url)
	if list_id:
		DB.execute("INSERT INTO list_movies(list_id, imdb_id, path) VALUES(?,?,?)", [list_id, imdb_id, movie_path])
	Notify("Movie added:", movie_title)
	
def EnableSubscription(imdb_id):
	ADDON.log("Enable subscription %s" % imdb_id)
	DB.execute("UPDATE subscriptions SET enabled=1 WHERE imdb_id=?", [imdb_id])
	DB.commit()
	REFRESH()

def DisableSubscription(imdb_id):
	ADDON.log("Disable subscription %s" % imdb_id)
	DB.execute("UPDATE subscriptions SET enabled=0 WHERE imdb_id=?", [imdb_id])
	DB.commit()
	REFRESH()

def AddFavorite(media, title, imdb_id):
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	if media=='TV':
		trakt.add_to_watchlist('shows', imdb_id)
	DB.execute("INSERT INTO favorites(media, name, imdb_id) VALUES(?,?,?)", [media, title, imdb_id])
	DB.commit()
	#REFRESH()
	Notify("Watchlist added:", title)

def ListSubscriptions():
	rows = DB.query("SELECT imdb_id, title, enabled FROM subscriptions ORDER BY title ASC", force_double_array=True)
	for row in rows:
		Ct = ContextMenu()
		if row[2]==1:
			Ct.add("Disable Subscription", {"mode": "tv_disable_subscription", "title": row[1], "imdb_id": row[0], "title": row[1]})
			display = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, row[1])
		else:
			Ct.add("Enable Subscription", {"mode": "tv_enable_subscription", "title": row[1], "imdb_id": row[0], "title": row[1]})
			display = row[1]
		Ct.add("Delete Subscription", {"mode": "tv_unsubscribe", "title": row[1], "imdb_id": row[0], "title": row[1]})
		MENU_ITEM({'mode': 'update_subscription', 'imdb_id': row[0]}, {"title": display}, menu=Ct)
	EOD("default-list_view")
	
def RemoveFavorite(media, title, imdb_id):
	dialog = xbmcgui.Dialog()
	if dialog.yesno("Remove", "Do you want to remove %s?" % title):
		from trakt_api import TraktAPI
		trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
		if media=='TV':
			trakt.remove_from_watchlist('shows', imdb_id)
		DB.execute("DELETE FROM favorites WHERE imdb_id=?", [imdb_id])
		DB.commit()
		REFRESH()
		Notify("Watchlist deleted:", title)

def ToggleHost(host):
	DB.execute("UPDATE hosts SET enabled=abs(enabled-1) WHERE host=?", [host])
	DB.commit()
	REFRESH()

def ManageHostList():
	rows = DB.query("SELECT host, enabled FROM hosts ORDER BY host ASC", force_double_array=True)
	for row in rows:
		if row[1] == 1:
			display = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, row[0])
		else:
			display = row[0]
		MENU_ITEM({'mode': 'toggle_host', 'host': row[0]}, {"title": display})
	EOD("default-list_view")

def SelectLanguage():
	languages = ["English", "French", "Spanish", "German", "Italian", "Hebrew"]
	dialog = xbmcgui.Dialog()
	lang_select = dialog.select('Select language', languages)
	if lang_select < 0:
		return False
	ADDON.set_setting("filter-lang", str(lang_select))

def AllucSearch(query=None, silent=False):
	global hash_id
	if not query:
		query = DoSearch('Search ' + ADDON_NAME)
		if query == 'What the Furk?': 
			ADDON.set_setting('show-furk', 'true')
			Notify("Furk.net", "Ok I'll enable Furk.",ART_PATH+'/furk.png')
			return
		elif not query: return
	hash_id = hashlib.md5(query).hexdigest()
	win = xbmcgui.Window(10000)
	win.setProperty(WINDOW_PREFIX+'.hashid', hash_id)
	cached_results = False
	if CACHE_RESULTS:			# Are we caching search results, if so check the database for freshly cached results
		rows = DB.query("SELECT display, url, host FROM cache_status WHERE fresh=1 AND hash_id=?", [hash_id], force_double_array=True)
		if rows:
			print "Loading from cache"
			results = []
			for row in rows:
				record = {"title": row[0], "url": row[1], "host": row[2]}
				results.append(record)
			silent = True
			cached_results = True
	if not cached_results:		# No cached results, so lets search
		results = []
		from alluc_api import AllucAPI
		alluc = AllucAPI(BASE_URL, APIKEY, CACHE_RESULTS)
		if FILTER_RESULTS:		# Are we limiting search resutls to host list
			if not silent:
				percent = 0
				index = 0
			hosts = DB.query("SELECT host FROM hosts WHERE enabled=1", force_double_array=True)
			if ADDON.get_bool_setting('enable-furk'):
				total = len(hosts) + 1
			else :
				temp = []
				for host in hosts: temp.append(host[0])
				hosts = ",".join(temp)
				results = alluc.search(query, hosts, FILTER_LANG)
		else:
			silent = True
			results = alluc.search(query, lang=FILTER_LANG)
	if SORT_BY_HOST:
		from operator import itemgetter
		results.sort(key=itemgetter('host'))

	dialog = xbmcgui.Dialog()
	streams = []
	options = []
	for result in results:
		streams.append(result['title'])
		options.append(result['url'])
	if ADDON.get_bool_setting('enable-furk'):
		from furk_api import FurkAPI
		furk = FurkAPI(ADDON.get_setting('furk-username'), ADDON.get_setting('furk-password'), ADDON.get_setting('furk-apikey'))
		furk_links = furk.search(query)
		for result in furk_links:
			streams.append(result['title'])
			options.append(result['url'])
	if len(results) == 0:
		Notify("No search results:", "Sorry no links returned")
		return False
	stream_select = dialog.select('Select mirror', streams)
	if stream_select < 0:
		return False
	raw_url = options[stream_select]
	if USE_METADATA:
		MH = metahandlers.MetaData()
		if args['mode']=='watch_episode':
			from trakt_api import TraktAPI
			trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
			metadata = MH.get_episode_meta(args['series'], args['imdb_id'], args['season'], args['episode'])
			metadata['cover_url'] = trakt.get_episode_screenshot(args['imdb_id'], args['season'], args['episode'])
		if args['mode']=='watch_movie':
			metadata = MH.get_meta('movie', args['title'], imdb_id=args['imdb_id'])
	WatchStream(raw_url, metadata)
	
def DoSearch(title):
	kb = xbmc.Keyboard('', title, False)
	kb.doModal()
	if (kb.isConfirmed()):
		search = kb.getText()
		if search != '':
			return search

def DoSelect(title, texts=[], options=[]):
	dialog = xbmcgui.Dialog()
	select = dialog.select(title, texts)
	if select < 0:
		return False
	result = options[select]
	return result

def WatchEpisode(args):
	s = str(args['season'])
	e = str(args['episode'])
	query = "%s S%sE%s" % (args['series'], s.zfill(2), e.zfill(2))
	AllucSearch(query)

def WatchMovie(title, year):
	query = "%s %s" % (title, year)
	AllucSearch(query)

def LaunchStream():
	if args['media'] == 'episode':
		from trakt_api import TraktAPI
		trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
		show = trakt.get_show_info(args['imdb_id'])
		args['series'] = show['title']
		args['mode'] = 'watch_episode'
		WatchEpisode(args)
	elif args['media'] == 'movie':
		from trakt_api import TraktAPI
		trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
		movie = trakt.get_movie_info(args['imdb_id'])
		args['mode']='watch_movie'
		args['title'] = movie['title']
		WatchMovie(movie['title'], movie['year'])
		
def WatchStream(raw_url, metadata={"cover_url": ''}):
	resolved_url = None
	if re.match('^furk://', raw_url):
		from furk_api import FurkAPI
		furk = FurkAPI(ADDON.get_setting('furk-username'), ADDON.get_setting('furk-password'), ADDON.get_setting('furk-apikey'))
		resolved_url = furk.resolve_url(raw_url)
		print resolved_url
	else:
		import urlresolver
		try:
			resolved_url = urlresolver.HostedMediaFile(url=raw_url).resolve()
		except Exception, e:
			pass
	if resolved_url is not None:
		StreamFile(resolved_url, metadata)
	else:
		Notify("UrlResolver failed:", "Unable to resolve host")
		print "Failed to resolve: %s" % raw_url

def StreamFile(url, metadata={"cover_url": ''}):
	if re.match('interfaces.unresolvable', str(url)):
		Notify('Streaming Error', 'Unable to resolve host')
		return False
	try:
		listitem = xbmcgui.ListItem('video', iconImage=metadata['cover_url'], thumbnailImage=metadata['cover_url'], path=url)
		listitem.setProperty('IsPlayable', 'true')
		listitem.setPath(url)
		listitem.setInfo('video', metadata)
	except Exception, e:
		return False
	win = xbmcgui.Window(10000)
	win.setProperty(WINDOW_PREFIX+'.playing', 'True')
	win.setProperty(WINDOW_PREFIX+'.metadata', json.dumps(metadata))
	'''test = DB.query("SELECT current  FROM player_state WHERE hash=?", [win.getProperty(WINDOW_PREFIX+'.hashid')])
	if test:
		import datetime, math
		current = float(test[0])
		if current > 30:
			seekTime = datetime.timedelta(seconds= math.floor(current))
			dialog = xbmcgui.Dialog()
			if dialog.yesno("Resume playback?","Do you want to resume play back from: %s" % str(seekTime)):
				win.setProperty(WINDOW_PREFIX+'.seekTime', str(current))
			PlayFile(listitem, url)
		else:
			PlayFile(listitem, url)
	else:
		PlayFile(listitem, url)'''
	PlayFile(listitem, url)
		
def PlayFile(listitem, url):
	try:
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	except Exception, e:
		ADDON.log( e )

def ShowAbout():
	path = vfs.join(ROOT_PATH, 'changelog.txt')
	file = vfs.open(path, 'r')
	changelog=file.read()
	file.close()
	path = vfs.join(ROOT_PATH + '/resources', 'welcome.html')
	file = vfs.open(path, 'r')
	content=file.read()
	content += '\n[COLOR red][B]Changelog[/B][/COLOR]\n\n' + changelog
	TextBox().show('Title Goes Here!', content)
	file.close()

def VersonCheck():
	if ADDON.get_setting('setup_run') != 'true':
		xbmc.executebuiltin('RunScript("plugin.video.alluc.api", "")')
		while True:
			if ADDON.get_setting('setup_run') == 'true': break
			xbmc.sleep(100)
		SetupLibrary(True)
		ADDON.set_setting('version',VERSION)
	current = VERSION
	previous = ADDON.get_setting('version')
	#if previous == '':
		#RunInitialSetup()
	#	return
	update = _check_version(previous, current)
	if update:
		RunUpdate()	
def _check_version(previous, current):
	if not re.search('\d+\.\d+\.\d+', str(previous)): return True
	p = previous.split('.')
	c = current.split('.')	
	# test major version
	if int(p[0]) < int(c[0]): return True
	# test minor version
	if int(p[1]) < int(c[1]): return True
	# test sub minor version
	if int(p[2]) < int(c[2]): return True
	return False
		
def RunInitialSetup():
	print "init"
	ok = Confirm("Welcome to Alluc Setup.", "A short setup is required. A valid Trakt.tv account is required.", "Are you ready to proceed?")
	if not ok: 
		xbmcgui.Dialog().ok("Welcome to Alluc Setup.","Alluc will now close.","Come back when you are ready.")
		sys_exit()
	xbmcaddon.Addon(id=ADDON_ID).openSettings()
	SetupLibrary(True)
	ADDON.set_setting('version',VERSION)

def RunUpdate():
	print "update"
	ADDON.set_setting('version',VERSION)

def ShowCutsomLists(media):
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	lists = trakt.get_custom_lists()
	MENU_ITEM({'mode': 'create_custom_list', "media": media}, {"title": '***'+get_str(30734)+'***'}, image=ART_PATH+'/create_trakt_list.jpg')
	sync_list = DB.query("SELECT id, slug, sync FROM lists", force_double_array=True)
	for list in lists:
		is_sync = False
		for li in sync_list:
			if li[2] == 1 and li[1]==list['ids']['slug']:
				is_sync = True
				break
		Ct = ContextMenu()
		if is_sync:
			display = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, list['name'])
			Ct.add(get_str(30740), {"mode": "unsync_%s_library" % media, 'slug': list['ids']['slug'], "media": media, "username": ADDON.get_setting('trakt-username'), "title": list['name']})
		else:
			display = list['name']
			Ct.add(get_str(30729), {"mode": "sync_%s_library" % media, 'slug': list['ids']['slug'], "media": media, "username": ADDON.get_setting('trakt-username'), "title": list['name']})
		Ct.add(get_str(30735), {"mode": "delete_custom_list", 'slug': list['ids']['slug'], "media": media, "username": ADDON.get_setting('trakt-username'), "title": list['name']})
		MENU_ITEM({'mode': media+'_custom_list', 'slug': list['ids']['slug'], "media": media}, {"title": display}, image=ART_PATH+'/trakt_list.jpg', menu=Ct)
	EOD('default-list-view')

def CreateCustomList():
	title = DoSearch(get_str(30737))
	if title:
		from trakt_api import TraktAPI
		trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
		lists = trakt.create_custom_list(title)
		REFRESH()

def DeleteCustomList(slug, title):
	ok = Confirm("Delete custom list", "Do you wish to delete list?", title)
	if ok:
		from trakt_api import TraktAPI
		trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
		trakt.delete_custom_list(slug)
		REFRESH()

def AddToCustomList(media, imdb_id, title):
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	lists = trakt.get_custom_lists()
	selects = []
	options = []
	for li in lists:
		selects.append(li['name'])
		options.append(li['ids']['slug'])
	slug = DoSelect('Select a list', selects, options)
	trakt.add_to_custom_list(media, slug, imdb_id)

def RemoveFromCustomList(media, slug, imdb_id, title):
	ok = Confirm("Remove from custom list", "Do you wish to remove this item?", title)
	if ok:
		from trakt_api import TraktAPI
		trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
		trakt.delete_from_custom_list(media, slug, imdb_id)
		REFRESH()
def MovieList(mode):
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	if mode == 'movie_trending':
		print "trending"
		movies = trakt.get_trending_movies()
	elif mode == 'movie_popular':
		print "popular"
		movies = trakt.get_popular_movies()
	elif mode == 'movie_recommended':
		print "recommended"
		movies = trakt.get_recommended_movies()
	elif mode == 'movie_search':
		print "search"
		query = DoSearch('Search Trakt.tv')
		movies = trakt.search(query, 'movie')
	elif mode == 'movie_custom_list':
		print "movie custom list"
		movies = trakt.get_custom_list(args['slug'], 'movie')
		print movies
	elif mode == 'movie_watchlist':
		print "watchlist"
		movies = trakt.get_watchlist_movies(DB)
	favorites = DB.query("SELECT imdb_id FROM favorites WHERE media='MOVIE'", force_double_array=True)
	if len(movies) > 0:
		PB.new("Fetching Movies", len(movies))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				MH = metahandlers.MetaData()
				metadata = MH.get_meta('movie', normalize(data['title']), imdb_id=data['imdb_id'])
				return [data, metadata]
			for movie in movies:
				pool.queueTask(lookup_task, movie, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['title'])
			for row in completed:
				add_movie_row(row[0], row[1], favorites)
		elif USE_METADATA and NUMBER_THREADS == 1:
			MH = metahandlers.MetaData()
			movies.sort(key=lambda x: x['title'])
			for movie in movies:
				metadata = MH.get_meta('movie', normalize(movie['title']), imdb_id=movie['imdb_id'])
				add_movie_row(movie, metadata, favorites)
		else:
			movies.sort(key=lambda x: x['display'])
			for movie in movies:
				metadata = {'title': movie['display']}
				add_movie_row(movie, metadata, favorites)
		PB.close()
	EOD('default-movie-view', 'movies')

def add_movie_row(movie, metadata, favorites):
	Ct = ContextMenu()
	PB.next(movie['display'])
	imdb_id = movie['imdb_id']
	title = movie['title']
	display = movie['display']
	fanart = movie['fanart']
	poster = movie['poster']
	year = movie['year']
	metadata['title'] = display	
	is_fav = False
	for test in favorites:
		if test[0]==imdb_id:
			is_fav = True
			break
	#try:
	Ct.add(get_str(30722), {"mode": "add_movie_library", "imdb_id": imdb_id, "title": title})
	if args['mode'] == 'movie_custom_list':
		Ct.add(get_str(30739), {"mode": "remove_from_custom_list", "imdb_id": imdb_id, "title": title, "media": "MOVIE", "slug": args['slug']})
	else:
		Ct.add(get_str(30738), {"mode": "add_to_custom_list", "imdb_id": imdb_id, "title": title, "media": "MOVIE"})
	if is_fav:
		if args['mode'] != 'movie_watchlist':
			metadata['title'] = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, display)
		Ct.add(get_str(30724), {"mode": "remove_favorite", "media": "MOVIE", "imdb_id": imdb_id, "title": title})
		MENU_ITEM({'mode': 'watch_movie', 'imdb_id': imdb_id, "fanart": fanart, 'title': title, 'year': year}, metadata, image=poster, fanart=fanart, menu=Ct,isPlayable=True)
	else:
		Ct.add(get_str(30723), {"mode": "add_favorites", "media": "MOVIE", "imdb_id": imdb_id, "title": title})
		MENU_ITEM({'mode': 'watch_movie', 'imdb_id': imdb_id, "fanart": fanart, 'title': title, 'year': year}, metadata, image=poster, fanart=fanart, menu=Ct,isPlayable=True)
	#except Exception, e:
	#	print e

def TVList(mode):
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))	
	if mode == 'tv_trending':
		print "trending"
		shows = trakt.get_trending_shows()
	elif mode == 'tv_popular':
		print "popular"	
		shows = trakt.get_popular_shows()
	elif mode == 'tv_recommended':
		print "recommended"
		shows = trakt.get_recommended_shows()
	elif mode == 'tv_search':
		print "search"
		query = DoSearch('Search Trakt.tv')
		shows = trakt.search(query, 'show')
	elif mode == 'tv_watchlist':
		print "watchlist"
		shows = trakt.get_watchlist_shows(DB)
	elif mode == 'tvshow_custom_list':
		print "tv custom list"
		shows = trakt.get_custom_list(args['slug'], 'tvshow')
	favorites = DB.query("SELECT imdb_id FROM favorites WHERE media='TV'", force_double_array=True)
	if len(shows) > 0:
		PB.new("Fetching TV Shows", len(shows))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				MH = metahandlers.MetaData()
				metadata = MH.get_meta('tvshow', normalize(data['title']), imdb_id=data['imdb_id'])
				return [data, metadata]
			for show in shows:
				pool.queueTask(lookup_task, show, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['title'])
			for row in completed:
				add_tvshow_row(row[0], row[1], favorites)
		elif USE_METADATA and NUMBER_THREADS == 1:
			MH = metahandlers.MetaData()
			shows.sort(key=lambda x: x['title'])
			for show in shows:
				metadata = MH.get_meta('tvshow', normalize(show['title']), imdb_id=show['imdb_id'])
				add_tvshow_row(show, metadata, favorites)
		else:
			shows.sort(key=lambda x: x['display'])
			for show in shows:
				metadata = {'title': show['display']}
				add_tvshow_row(show, metadata, favorites)
		PB.close()
	EOD('default-tvshow-view', 'tvshows')

def add_tvshow_row(show, metadata, favorites):
	PB.next(show['display'])
	Ct = ContextMenu()
	imdb_id = show['imdb_id']
	title = show['title']
	display = show['display']
	fanart = show['fanart']
	poster = show['poster']
	year = show['year']
	metadata['title'] = display
	is_fav = False
	for test in favorites:
		if test[0]==imdb_id:
			is_fav = True
			break
	Ct.add("Subscribe", {"mode": "tv_subscribe", "imdb_id": imdb_id, "title": title})
	if args['mode'] == 'tv_custom_list':
		Ct.add(get_str(30739), {"mode": "remove_from_custom_list", "imdb_id": imdb_id, "title": title, "media": "TV", "slug": args['slug']})
	else:
		Ct.add(get_str(30738), {"mode": "add_to_custom_list", "imdb_id": imdb_id, "title": title, "media": "TV"})
	if is_fav:
		if args['mode'] != 'tv_watchlist':
			metadata['title'] = "[COLOR %s]%s[/COLOR]" % (ENABLED_COLOR, title)
		Ct.add(get_str(30724), {"mode": "remove_favorite", "media": "TV", "imdb_id": imdb_id, "title": title})
		MENU_ITEM({'mode': 'tv_seasons', 'imdb_id': imdb_id, "fanart": fanart, 'series': title}, metadata, image=poster, fanart=fanart, menu=Ct)
	else:
		Ct.add(get_str(30723), {"mode": "add_favorites", "media": "TV", "imdb_id": imdb_id, "title": title})
		MENU_ITEM({'mode': 'tv_seasons', 'imdb_id': imdb_id, "fanart": fanart, 'series': title}, metadata, image=poster, fanart=fanart, menu=Ct)


def MyCalendar():
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	episodes = trakt.get_calendar_shows()
	if len(episodes) > 0:
		PB.new("Fetching Episodes", len(episodes))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				MH = metahandlers.MetaData()
				metadata = MH.get_episode_meta(normalize(data['title']), data['imdb_id'], data['season'], data['episode'])
				return [data, metadata]
			for episode in episodes:
				pool.queueTask(lookup_task, episode, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['aired'])
			for row in completed:
				add_calendar_row(row[0], row[1])
		elif USE_METADATA and NUMBER_THREADS==1:
			MH = metahandlers.MetaData()
			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				metadata = MH.get_episode_meta(normalize(episode['title']), episode['imdb_id'], episode['season'], episode['episode'])
				add_calendar_row(episode, metadata)
		else:

			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				metadata = {'title': episode['display']}
				add_calendar_row(episode, metadata)
		PB.close()
	EOD('default-episode-view', 'episodes')

def add_calendar_row(row, metadata):
	Ct = ContextMenu()
	PB.next(row['display'])
	series = row['series']
	imdb_id = row['imdb_id']
	poster = row['poster']
	fanart = row['fanart']
	episode = str(row['episode'])
	season = str(row['season'])
	metadata['title'] = row['display']
	if getKeyVal(metadata, 'overlay')==7:
		Ct.add(get_str(30726), {'mode': 'mark_unwatched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	else:
		Ct.add(get_str(30725), {'mode': 'mark_watched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	MENU_ITEM({'mode': 'watch_episode', 'imdb_id': imdb_id, 'season': season, 'episode': episode, 'series': series}, metadata, image=poster, fanart=fanart, menu=Ct, isPlayable=True)
	
def TVListSeasons(imdb_id, series='', fanart=""):
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))	
	seasons = trakt.get_show_seasons(imdb_id)
	for season in seasons:
		n = str(season['number'])
		if n != "0":
			image = season['images']['poster']['full']
			MENU_ITEM({'mode': 'tv_episodes', 'imdb_id': imdb_id, 'season': n, "fanart": fanart, "series": series}, {'title': "Season " + n}, image=image, fanart=fanart)
	EOD('default-season-view', 'tvshows')

def TVListEpisodes(imdb_id, season, series='', fanart=""):
	from datetime import datetime, date
	today = date.today()
	from trakt_api import TraktAPI
	trakt = TraktAPI(username=ADDON.get_setting('trakt-username'), password=ADDON.get_setting('trakt-password'))
	episodes = trakt.get_show_episodes(imdb_id, season)
	if len(episodes) > 0:
		PB.new("Fetching Episodes", len(episodes))
		if USE_METADATA and NUMBER_THREADS > 1:
			from threadpool import ThreadPool
			pool = ThreadPool(NUMBER_THREADS)
			completed = []
			def complete_task(data):
				completed.append(data)
			def lookup_task(data):
				MH = metahandlers.MetaData()
				data['imdb_id'] = imdb_id
				data['series'] = series
				data['fanart'] = fanart
				metadata = MH.get_episode_meta(normalize(data['title']), data['imdb_id'], data['season'], data['episode'])
				return [data, metadata]
			for episode in episodes:
				pool.queueTask(lookup_task, episode, complete_task)
			pool.joinAll()
			completed.sort(key=lambda x: x[0]['aired'])
			for row in completed:
				add_episode_row(row[0], row[1])
		elif USE_METADATA and NUMBER_THREADS == 1:
			MH = metahandlers.MetaData()
			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				episode['imdb_id'] = imdb_id
				episode['series'] = series
				episode['fanart'] = fanart
				metadata = MH.get_episode_meta(normalize(episode['title']), episode['imdb_id'], episode['season'], episode['episode'])
				add_episode_row(episode, metadata)
		else:
			episodes.sort(key=lambda x: x['aired'])
			for episode in episodes:
				episode['imdb_id'] = imdb_id
				episode['series'] = series
				episode['fanart'] = fanart
				metadata = {'title': episode['display']}
				add_episode_row(episode, metadata)
		PB.close()
	EOD('default-episode-view', 'tvshows')

def add_episode_row(row, metadata):
	PB.next(row['display'])
	series = row['series']
	imdb_id = row['imdb_id']
	poster = row['poster']
	fanart = row['fanart']
	episode = str(row['episode'])
	season = str(row['season'])
	metadata['title'] = row['display']
	Ct = ContextMenu()
	if getKeyVal(metadata, 'overlay')==7:
		Ct.add(get_str(30726), {'mode': 'mark_unwatched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	else:
		Ct.add(get_str(30725), {'mode': 'mark_watched', 'media': 'episode', 'title': series, 'imdb': imdb_id, 'season': season, 'episode': episode})
	MENU_ITEM({'mode': 'watch_episode', 'imdb_id': imdb_id, 'season': season, 'episode': episode, 'series': series},metadata, image=poster, fanart=fanart, menu=Ct, isPlayable=True)
		
############################
### Menus		         ###
############################

def MainMenu():
	ADDON.log("main menu")
	MENU_ITEM({'mode': 'tv_menu'}, {'title': get_str(30700)}, image=ART_PATH+'/tvshows.jpg')
	MENU_ITEM({'mode': 'movie_menu'}, {'title': get_str(30701)}, image=ART_PATH+'/movies.jpg')
	MENU_ITEM({'mode': 'set_language'}, {'title': get_str(30702)}, image=ART_PATH+'/languages.jpg')
	MENU_ITEM({'mode': 'quick_search'}, {'title': get_str(30703)}, image=ART_PATH+'/search_quick.jpg')
	MENU_ITEM({'mode': 'settings'}, {'title': get_str(30704)}, image=ART_PATH+'/settings_alluc.jpg')
	MENU_ITEM({'mode': 'autoupdate_all'}, {'title': get_str(30736)}, image=ART_PATH+'/update_now.jpg')
	EOD()
	
def TVMenu():
	ADDON.log("tv menu")
	MENU_ITEM({'mode': 'tv_calendar'}, {'title': get_str(30705)}, image=ART_PATH+'/calendar.jpg')
	MENU_ITEM({'mode': 'tv_watchlist'}, {'title': get_str(30706)}, image=ART_PATH+'/watchlist.jpg')
	MENU_ITEM({'mode': 'tv_custom_lists'}, {'title': get_str(30730)}, image=ART_PATH+'/custom_list.jpg')
	MENU_ITEM({'mode': 'tv_search'}, {'title': get_str(30710)}, image=ART_PATH+'/search.jpg')
	MENU_ITEM({'mode': 'tv_recommended'}, {'title': get_str(30707)}, image=ART_PATH+'/recommended.jpg')
	MENU_ITEM({'mode': 'tv_popular'}, {'title': get_str(30708)}, image=ART_PATH+'/popular.jpg')
	MENU_ITEM({'mode': 'tv_trending'}, {'title': get_str(30709)}, image=ART_PATH+'/trending.jpg')
	
	EOD()
	
def MovieMenu():
	ADDON.log("movie menu")
	MENU_ITEM({'mode': 'movie_watchlist'}, {'title': get_str(30711)}, image=ART_PATH+'/watchlist.jpg')
	MENU_ITEM({'mode': 'movie_custom_lists'}, {'title': get_str(30712)}, image=ART_PATH+'/custom_list.jpg')
	MENU_ITEM({'mode': 'movie_recommended'}, {'title': get_str(30713)}, image=ART_PATH+'/recommended.jpg')
	MENU_ITEM({'mode': 'movie_popular'}, {'title': get_str(30714)}, image=ART_PATH+'/popular.jpg')
	MENU_ITEM({'mode': 'movie_trending'}, {'title': get_str(30715)}, image=ART_PATH+'/trending.jpg')
	MENU_ITEM({'mode': 'movie_search'}, {'title': get_str(30716)}, image=ART_PATH+'/search.jpg')
	EOD()
	
def SettingsMenu():
	ADDON.log("settings menu")
	MENU_ITEM({'mode': 'add_source_folders'}, {'title': get_str(30727)}, image=ART_PATH+'/add_source_folders.jpg')
	MENU_ITEM({'mode': 'manage_subscriptions'}, {'title': get_str(30717)}, image=ART_PATH+'/subscriptions.jpg')
	if FILTER_RESULTS:
		MENU_ITEM({'mode': 'manage_hostlist'}, {'title': get_str(30728)}, image=ART_PATH+'/hoster_list.jpg')
	MENU_ITEM({'mode': 'alluc_settings'}, {'title': get_str(30704)}, image=ART_PATH+'/settings_alluc.jpg')
	MENU_ITEM({'mode': 'urlresolver_settings'}, {'title': get_str(30718)}, image=ART_PATH+'/urlresolver.jpg')
	MENU_ITEM({'mode': 'metahandler_settings'}, {'title': get_str(30719)}, image=ART_PATH+'/metahandler.jpg')
	EOD()
############################
### Modes		         ###
############################

args = ADDON.parse_query(sys.argv[2])
ADDON.log(args)
if args['mode'] not in 		['import_keyfile']:
	VersonCheck()
#Main Menu
if args['mode'] == 			'main':
	MainMenu()
elif args['mode'] == 		'tv_menu':
	TVMenu()
elif args['mode'] == 		'quick_search':
	AllucSearch()
elif args['mode'] == 		'movie_menu':
	MovieMenu()	
elif args['mode'] == 		'set_language':
	SelectLanguage()
elif args['mode'] == 		'settings':
	SettingsMenu()
	
#TV Menus
elif args['mode'] in 		['tv_trending', 'tv_recommended', 'tv_popular', 'tv_watchlist', 'tv_search', 'tvshow_custom_list']:
	TVList(args['mode'])
elif args['mode'] == 		'tv_calendar':
	MyCalendar()
elif args['mode'] == 		'tv_seasons':
	TVListSeasons(args['imdb_id'], args['series'], args['fanart'])
elif args['mode'] == 		'tv_episodes':
	TVListEpisodes(args['imdb_id'], args['season'], args['series'], args['fanart'])
elif args['mode'] == 		'tv_custom_lists':
	ShowCutsomLists('tvshow')	
#Movie Menus
elif args['mode'] in 		['movie_trending', 'movie_recommended', 'movie_popular', 'movie_watchlist', 'movie_search', 'movie_custom_list']:
	MovieList(args['mode'])
elif args['mode'] == 		'movie_custom_lists':
	ShowCutsomLists('movie')	

#Settings Menu
elif args['mode'] == 	'alluc_settings':
	xbmcaddon.Addon(id=ADDON_ID).openSettings()
elif args['mode'] == 	'urlresolver_settings':
	xbmcaddon.Addon(id='script.module.urlresolver').openSettings()
elif args['mode'] == 	'metahandler_settings':
	xbmcaddon.Addon(id='script.module.metahandler').openSettings()
elif args['mode'] == 	'add_source_folders':
	SetupLibrary()
elif args['mode'] == 		'manage_subscriptions':
	ListSubscriptions()	
elif args['mode'] == 		'manage_hostlist':
	ManageHostList()
			
#Update Functions
elif args['mode'] == 		'update_subscription':
	UpdateSubscription(args['imdb_id'])
elif args['mode'] == 		'autoupdate_tv':
	Autoupdate('TV')
elif args['mode'] == 		'autoupdate_movie':
	Autoupdate('MOVIE')
elif args['mode'] == 		'autoupdate_library':
	Autoupdate('LIBRARY')
elif args['mode'] == 		'autoupdate_all':
	Autoupdate('TV')
	Autoupdate('MOVIE')	

#Stream Functions
elif args['mode'] ==		'watch_episode':
	WatchEpisode(args)
elif args['mode'] ==		'watch_movie':
	WatchMovie(args['title'], args['year'])
elif args['mode'] ==		'watch_stream':
	LaunchStream()

#Misc Functions
elif args['mode'] in 		['mark_watched', 'mark_unwatched']:
	ToggleWatchedState()
elif args['mode'] ==		'service_mark_watched':
	SetPlayCount(args, 1)
elif args['mode'] == 		'add_movie_library':
	AddMovieToLibrary(args['imdb_id'])
elif args['mode'] ==		'add_favorites':
	AddFavorite(args['media'], args['title'], args['imdb_id'])
elif args['mode'] == 		'tv_subscribe':
	Subscribe(args['imdb_id'], args['title'])
elif args['mode'] == 		'tv_unsubscribe':
	Unsubscribe(args['imdb_id'], args['title'])
elif args['mode'] == 		'tv_enable_subscription':
	EnableSubscription(args['imdb_id'])
elif args['mode'] == 		'tv_disable_subscription':
	DisableSubscription(args['imdb_id'])
elif args['mode'] ==		'remove_favorite':
	RemoveFavorite(args['media'], args['title'], args['imdb_id'])
elif args['mode'] ==		'delete_custom_list':
	DeleteCustomList(args['slug'], args['title'])
elif args['mode'] ==		'create_custom_list':
	CreateCustomList()
elif args['mode'] ==		'add_to_custom_list':
	AddToCustomList(args['media'],args['imdb_id'], args['title'])
elif args['mode'] ==		'remove_from_custom_list':
	RemoveFromCustomList(args['media'],args['slug'], args['imdb_id'], args['title'])
elif args['mode'] in 		['sync_movie_library', 'sync_tvshow_library']:
	SyncList(args['title'], args['username'],args['slug'], args['media'])
elif args['mode'] in 		['unsync_movie_library', 'unsync_tvshow_library']:
	UnSyncList(args['title'], args['username'], args['slug'])
elif args['mode'] == 		'toggle_host':
	ToggleHost(args['host'])


