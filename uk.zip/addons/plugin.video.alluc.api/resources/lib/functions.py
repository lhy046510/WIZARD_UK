import os
import sys
import re
import urllib
import xbmc
import xbmcgui
import xbmcvfs
import xbmcplugin
import xbmcaddon

from commonlib import *
def normalize(string):
	return unicodedata.normalize('NFKD', unicode(string)).encode('ascii','ignore')

def sys_exit():
	exit = xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
	return exit

def get_str(id):
	return xbmcaddon.Addon(ADDON_ID).getLocalizedString(id=id)

def REFRESH():
	xbmc.executebuiltin("Container.Refresh")

def Notify(title, message, image=None):
	if not image:
		vfs = Vfs()
		image = vfs.join(ADDON.get_path(), 'icon.png')
	xbmc.executebuiltin("XBMC.Notification("+title+","+message+",1500,"+image+")")

def Confirm(title, msg1='', msg2=''):
	dialog = xbmcgui.Dialog()
	return dialog.yesno(title, msg1, msg2)

def getKeyVal(item, key):
	try:
		return item[key]
	except:
		return None

	

def get_active_resolvers():
	import urlresolver
	domains = []
	for resolver in urlresolver.UrlResolver.implementors():
		if resolver.domains:
			for domain in resolver.domains: 
				if re.match('^(.+?)\.(.+?)$', domain): domains.append(domain)
	return domains	

def format_size(size):
	size = int(size) / (1024 * 1024)
	if size > 2000:
		size = size / 1024
		unit = 'GB'
	else :
		unit = 'MB'
	size = "%s %s" % (size, unit)
	return size

class Vfs:
	def __init__(self, root='/', debug=False):
		self.debug = debug
		self.root = root
	
	def _resolve_path(self, path):
		return path.replace('/', os.sep)	

	def confirm(self, msg='', msg2='', msg3=''):
		dialog = xbmcgui.Dialog()
		return dialog.yesno(msg, msg2, msg3)

	def open(self, path, mode='r'):
		try:
			return xbmcvfs.File(path, mode)
		except Exception, e:
			xbmc.log('******** VFS error: %s' % e)
			return False

	def touch(self, path):
		try:
			if self.exists(path):
				self.open(path, 'r')
				return True
			else:
				self.open(path, 'w')
				return True
		except Exception, e:
			xbmc.log('******** VFS error: %s' % e)
			return False

	def exists(self, path):
		return xbmcvfs.exists(path)

	def ls(self, path):
		try:
			return xbmcvfs.listdir(path)
		except Exception, e:
			xbmc.log('******** VFS error: %s' % e)
			return False

	def mkdir(self, path, recursive=False):
		if self.exists(path):
			if self.debug:
				xbmc.log('******** VFS mkdir notice: %s exists' % path)
			return False
		if recursive:
			try:
				return xbmcvfs.mkdirs(path)
			except Exception, e:
				xbmc.log('******** VFS error: %s' % e)
				return False
		else:
			try:
				return xbmcvfs.mkdir(path)
			except Exception, e:
				xbmc.log('******** VFS error: %s' % e)
				return False

	def rmdir(self, path, quiet=False):
		if not self.exists(path):
			if self.debug:
				xbmc.log('******** VFS rmdir notice: %s does not exist' % path)
			return False
		if not quiet:
			msg = 'Remove Directory'
			msg2 = 'Please confirm directory removal!'
			if not self.confirm(msg, msg2, path): return False
		try:		
			xbmcvfs.rmdir(path)
		except Exception, e:
			xbmc.log('******** VFS error: %s' % e)

	def rm(self, path, quiet=False, recursive=False):
		if not self.exists(path):
			if self.debug:
				xbmc.log('******** VFS rmdir notice: %s does not exist' % path)
			return False
		if not quiet:
			msg = 'Confirmation'
			msg2 = 'Please confirm directory removal!'
			if not self.confirm(msg, msg2, path): return False

		if not recursive:
			try:
				xbmcvfs.delete(path)
			except Exception, e:
				xbmc.log('******** VFS error: %s' % e)
		else:
			dirs,files = self.ls(path)
			for f in files:
				rm = os.path.join(xbmc.translatePath(path), f)
				try:
					xbmcvfs.delete(rm)
				except Exception, e:
					xbmc.log('******** VFS error: %s' % e)
			for d in dirs:
				subdir = os.path.join(xbmc.translatePath(path), d)
				self.rm(subdir, quiet=True, recursive=True)
			try:			
				xbmcvfs.rmdir(path)
			except Exception, e:
				xbmc.log('******** VFS error: %s' % e)
	def cp(self, src, dest):
		pass

	def mv(self, src, dest):
		pass

	def join(self, path,filename, preserve=False):
		path = path.replace('/', os.sep)
		if not preserve:
			translatedpath = os.path.join(xbmc.translatePath( path ), ''+filename+'')
		else:
			translatedpath = os.path.join(path, ''+filename+'')
		return translatedpath

class TextBox:
	# constants
	WINDOW = 10147
	CONTROL_LABEL = 1
	CONTROL_TEXTBOX = 5

	def __init__( self, *args, **kwargs):
		# activate the text viewer window
		xbmc.executebuiltin( "ActivateWindow(%d)" % ( self.WINDOW, ) )
		# get window
		self.window = xbmcgui.Window( self.WINDOW )
		# give window time to initialize
		xbmc.sleep( 500 )


	def setControls( self ):
		#get header, text
		heading, text = self.message
		# set heading
		self.window.getControl( self.CONTROL_LABEL ).setLabel( "%s - %s v%s" % ( heading, ADDON_NAME, VERSION) )
		# set text
		self.window.getControl( self.CONTROL_TEXTBOX ).setText( text )

	def show(self, heading, text):
		# set controls

		self.message = heading, text
		self.setControls()