import urllib2, urllib
from commonlib import *
try: 
	import simplejson as json
except ImportError: 
	import json 
API_KEY="eb41e95243d8c95152ed72a1fc0394c93cb785cb33aed609fdde1a07454584b4"
BASE_URL = "http://api-v2launch.trakt.tv"
DAYS_TO_GET = 21
class TraktAPI():
	def __init__(self, username, password, token=""):
		self.token = token
		self.username=username
		self.password=password
		self._login()

	def _login(self):
		data = {'login': self.username, 'password': self.password}		
		uri = '/auth/login'
		response = self._call(uri, data)
		if not response:
			print "Authentication failed"
			return
		self.token = response['token']

	def add_to_watchlist(self, media, imdb_id):
		uri = '/sync/watchlist'
		data = {media:  [{'ids': {'imdb': imdb_id}}]}
		self._call(uri, data)
	
	def remove_from_watchlist(self, media, imdb_id):
		uri = '/sync/watchlist/remove'
		data = {media:  [{'ids': {'imdb': imdb_id}}]}
		self._call(uri, data)
	
	def search(self, query, media='show'):
		uri = '/search'
		results =  self._call(uri, params={'query': query, 'type': media})
		if media=='show':
			return self._process_records(results, 'show')
		else:
			return self._process_records(results, 'movie')
	def get_watchlist_shows(self, DB):
		uri = '/users/%s/watchlist/shows' % self.username
		response = self._process_records(self._call(uri, params={'extended': 'full,images'}), 'show')
		DB.execute("DELETE from favorites WHERE media='TV'")
		for r in response:
			DB.execute("INSERT INTO favorites(media, name, imdb_id) VALUES(?,?,?)", ['TV', r['title'], r['imdb_id']])
		DB.commit()
		return response
	
	def get_watchlist_movies(self, DB):
		uri = '/users/%s/watchlist/movies' % self.username
		response = self._process_records(self._call(uri, params={'extended': 'full,images'}), 'movie')
		DB.execute("DELETE from favorites WHERE media='MOVIE'")
		for r in response:
			DB.execute("INSERT INTO favorites(media, name, imdb_id) VALUES(?,?,?)", ['MOVIE', r['title'], r['imdb_id']])
		DB.commit()
		return response

	def get_collection(self, media):
		uri = '/users/%s/collection/%s' % (self.username, media)
		return self._call(uri, params={})

	def get_custom_lists(self):
		uri = '/users/%s/lists' % self.username
		return self._call(uri, params={})

	def get_custom_list(self, slug, media, username=None):
		if media=='tvshow': media = 'show'
		if not username: username = self.username
		uri = '/users/%s/lists/%s/items' % (username, slug)
		temp = self._call(uri, params={'extended': 'full,images'})
		results = []
		for r in temp:
			if r['type'] == media:
				results.append(r)
		if media=='show':
			return self._process_records(results, 'show')
		else:
			return self._process_records(results, 'movie')
	
	def create_custom_list(self, title):
		uri = '/users/%s/lists' % self.username
		post_dict = {
			"name": title,
    		"description": "Created by Alluc.API",
  	   		"privacy": "public",
    	   	"display_numbers": True,
		   	"allow_comments": True
		}
		self._call(uri, data=post_dict)

	def add_to_custom_list(self, media, slug, imdb_id):
		if media=='MOVIE':
			post_dict = {'movies': [{'ids': {"imdb": imdb_id}}]}
		else:
			post_dict = {'shows': [{'ids': {"imdb": imdb_id}}]}
		uri = '/users/%s/lists/%s/items' % (self.username, slug)
		self._call(uri, data=post_dict)
		
	def delete_from_custom_list(self, media, slug, imdb_id):
		if media=='MOVIE':
			post_dict = {'movies': [{'ids': {"imdb": imdb_id}}]}
		else:
			post_dict = {'shows': [{'ids': {"imdb": imdb_id}}]}
		uri = '/users/%s/lists/%s/items/remove' % (self.username, slug)
		self._call(uri, post_dict)
		
	def delete_custom_list(self, slug):
		uri = '/users/%s/lists/%s' % (self.username, slug)
		print self._delete(uri)

	def get_trending_movies(self):
		uri = '/movies/trending'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'movie')

	def get_popular_movies(self):
		uri = '/movies/popular'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'movie')
	
	def get_recommended_movies(self):
		uri = '/recommendations/movies'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'movie')
	
	def _process_records(self, records, media='movie'):
		processed = []
		if media=='episode':
			from datetime import datetime
			import re, time
			#timezone = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}'))['result']['value']
			for record in records:
				if 'episode' in record.keys():
					tmp = re.match('^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\.000Z', record['episode']['first_aired'])
					aired = datetime(int(tmp.group(1)), int(tmp.group(2)),int(tmp.group(3)),int(tmp.group(4)),int(tmp.group(5)),int(tmp.group(6)))
					aired = time.mktime(aired.timetuple())
					series = record['show']['title']
					season = record['episode']['season']
					episode = record['episode']['number']
					series = record['show']['title']
					title = record['episode']['title']
					poster = record['show']['images']['poster']['full']
					fanart = record['show']['images']['fanart']['full']
					imdb_id = record['show']['ids']['imdb']
					display = "%s %sx%s %s" %(series, season, episode, title)
					processed.append({'imdb_id': imdb_id, 'title': title, "poster": poster, "fanart": fanart, "display": display, "series": series, "season": season, "episode": episode, "aired": aired})
				else:
					if 'first_aired' in record.keys() and record['first_aired'] is not None:
						tmp = re.match('^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\.000Z', record['first_aired'])
						aired = datetime(int(tmp.group(1)), int(tmp.group(2)),int(tmp.group(3)),int(tmp.group(4)),int(tmp.group(5)),int(tmp.group(6)))
						aired = time.mktime(aired.timetuple())
						now = time.mktime(datetime.now().timetuple())
						if aired < now:
							title = record['title']
							season = record['season']
							episode = record['number']
							poster = record['images']['screenshot']['full']
							display = "%sx%s - %s" % (season, episode, title)
							processed.append({'title': title, "display": display, "poster": poster, "season": season, "episode": episode, "aired": aired})
			return processed
		for record in records:
			if media in record:
				title = record[media]['title']
				imdb_id = record[media]['ids']['imdb']
				poster = record[media]['images']['poster']['full']
				fanart = record[media]['images']['fanart']['full']
				try:
					year = record[media]['released'][0:4]
				except:
					year = record[media]['year']
			else:
				title = record['title']
				imdb_id = record['ids']['imdb']
				poster = record['images']['poster']['full']
				fanart = record['images']['fanart']['full']
				try:
					year = record['released'][0:4]
				except:
					year = record['year']
			if title is not None:
				display = "%s (%s)" % (title, year)
				processed.append({'imdb_id': imdb_id, 'title': title, "poster": poster, "fanart": fanart, "display": display, "year": year})
			#else:
			#	display = "%s (%s)" % (title, year)
			#	processed.append({'imdb_id': imdb_id, 'title': title, "poster": poster, "fanart": fanart, "display": display, "year": year})
		return processed
	
	def get_trending_shows(self):
		uri = '/shows/trending'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'show')

	def get_popular_shows(self):
		uri = '/shows/popular'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'show')
	
	def get_recommended_shows(self):
		uri = '/recommendations/shows'
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'show')
	
	def get_show_seasons(self, imdb_id):
		uri = '/shows/%s/seasons' % imdb_id
		return self._call(uri, params={'extended': 'images'})
	
	def get_show_episodes(self, imdb_id, season):
		uri = '/shows/%s/seasons/%s' % (imdb_id, season)
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'episode')
	
	def get_episode_screenshot(self, imdb_id, season, episode):
		uri = '/shows/%s/seasons/%s/episodes/%s' %(imdb_id, season, episode)
		response = self._call(uri, params={'extended': 'images'})
		return response['images']['screenshot']['full']
	
	def get_show_info(self, imdb_id, episodes=False):
		if episodes:
			uri = '/shows/%s/seasons' % imdb_id
			return self._call(uri, params={'extended': 'episodes,full'})
		else:
			uri = '/shows/%s' % imdb_id
			return self._call(uri)
	
	def get_movie_info(self, imdb_id):
		uri = '/movies/%s' % imdb_id
		return self._call(uri, params={})
	
	def get_episode_info(self, imdb_id, season, episode):
		uri = '/shows/%s/seasons/%s/episodes/%s' % (imdb_id, season, episode)
		response = self._call(uri, params={'extended': 'images'})
		
	def get_calendar_shows(self):
		from datetime import date, timedelta
		d = date.today() - timedelta(days=DAYS_TO_GET)
		today = d.strftime("%Y-%m-%d")
		uri = '/calendars/my/shows/%s/%s' % (today, DAYS_TO_GET)
		return self._process_records(self._call(uri, params={'extended': 'full,images'}), 'episode')
	
	def _call(self, uri, data=None, params=None, auth=True):
		json_data = json.dumps(data) if data else None
		headers = {'Content-Type': 'application/json', 'trakt-api-key': API_KEY, 'trakt-api-version': 2}
		if auth: headers.update({'trakt-user-login': self.username, 'trakt-user-token': self.token})
		url = '%s%s' % (BASE_URL, uri)
		if params:
			params['limit'] = 100
		else:
			params = {'limit': 100}
		url = url + '?' + urllib.urlencode(params)
		try:
			request = urllib2.Request(url, data=json_data, headers=headers)
			f = urllib2.urlopen(request)
			result = f.read()
			response = json.loads(result)
		except Exception, e:
			print e
			return False
		return response
	
	def _delete(self, uri, data=None, params=None, auth=True):
		json_data = json.dumps(data) if data else None
		url = '%s%s' % (BASE_URL, uri)
		opener = urllib2.build_opener(urllib2.HTTPHandler)
		headers = {'Content-Type': 'application/json', 'trakt-api-key': API_KEY, 'trakt-api-version': 2}
		if auth: headers.update({'trakt-user-login': self.username, 'trakt-user-token': self.token})
		request = urllib2.Request(url, data=json_data, headers=headers)
		request.get_method = lambda: 'DELETE'
		response = opener.open(request)
