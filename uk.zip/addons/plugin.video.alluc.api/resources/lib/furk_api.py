import urllib2
import urllib
import re
import xbmcgui
from commonlib import *
try: 
	import simplejson as json
except ImportError: 
	import json

REFERRER = 'http://furk.net'
BASE_URL = 'https://api.furk.net/api/'
SIZE_COLOR = 'blue'
HOST_COLOR = 'red'
MEDIA_COLOR = 'green'
class FurkAPI():
	def __init__(self, username, password, api_key=""):
		self.api_key = api_key
		self.username=username
		self.password=password
		#self._login()
		
	def _login(self):
		#if not self.api_key:
		post_dict = {"login": self.username, "pwd": self.password}
		uri = '/login/login'
		response = self._call("/login/login", params=post_dict)
		if 'status' in response.keys():
			if response['status'] == 'ok':
				self.api_key = response['api_key']
				ADDON.set_setting('trakt-apikey', self.api_key)
			else:
				print response
		else:
			print response
		return self.api_key
	
	def _clean_query(self, query):
		cleaned = query
		cleaned = cleaned.replace(":", '')
		cleaned = cleaned.replace("'", '')
		cleaned = cleaned.replace("-", ' ')
		cleaned = cleaned.replace("_", ' ')
		return cleaned
	
	def _format_results(self, data):
		results = []
		if 'files' not in data.keys() : return results
		files = data['files']
		for f in files:
			if f['type'] == 'video':
				bitrate = re.search('bitrate: (.+?) kb/s', f['video_info'])
				if bitrate:
					bitrate = " %s kb/s" % bitrate.group(1)
				else:
					bitrate = ''
				raw_url = "furk://%s" % f['id']
				name = f['name']
				size = int(f['size']) / (1024 * 1024)
				if size > 2000:
					size = size / 1024
					unit = 'GB'
				else :
					unit = 'MB'
				formated = "[COLOR %s]furk.net[/COLOR]: ([COLOR %s]%s %s%s[/COLOR]) %s" % (HOST_COLOR, SIZE_COLOR, size, unit, bitrate, name)
				results.append({"title": formated, "url": raw_url})
		return results
	
	def search(self, query):
		api_key = self._login()
		post_dict = {"type": "video", "filter": "cached", "api_key": api_key, "q": self._clean_query(query)}
		data = self._call("/plugins/metasearch", post_dict)
		results = self._format_results(data)
		return results
	
	def resolve_url(self, raw_url):
		api_key = self._login()
		id = raw_url[7:len(raw_url)]
		t_files = []
		t_options = []
		dialog = xbmcgui.Dialog()
		post_dict = {"type": "video", "id": id, "api_key": api_key, 't_files': 1}
		results = self._call("/file/get", post_dict)
		if results=='':
			return False
		files = results['files'][0]['t_files']
		for f in files:
			if re.search('^video/', f['ct']):
				size = int(f['size']) / (1024 * 1024)
				if size > 2000:
					size = size / 1024
					unit = 'GB'
				else :
					unit = 'MB'
				if re.search('\.mp4$', f['name']):
					m_type = 'MP4'
				elif re.search('\.mkv$', f['name']):
					m_type = 'MKV'	
				else:
					m_type = 'AVI'
				formated = "(%s-[COLOR %s]%s %s[/COLOR]) %s" % (m_type, SIZE_COLOR, size, unit, f['name'])
				t_files.append(formated)
				t_options.append(f['url_dl'])
		file_select = dialog.select('Select Furk Stream', t_files)
		if file_select < 0:
			return None
		resolved_url = str(t_options[file_select])
		return resolved_url
		
	def _call(self, uri,params=None):
		url = '%s%s' % (BASE_URL, uri)
		if params:
			params['pretty'] = 1
		else:
			params = {'pretty': 1}
		if self.api_key:
			params['api_key'] = self.api_key
		paramsenc = urllib.urlencode(params)
		req = urllib2.Request(url, paramsenc)
		opener = urllib2.build_opener()
		response = opener.open(req)
		body = json.loads(response.read())
		return body


		