CREATE TABLE IF NOT EXISTS favorites (id INTEGER PRIMARY KEY AUTOINCREMENT, media TEXT default "TV", name TEXT, imdb_id TEXT UNIQUE, new INTEGER default 0);

CREATE TABLE IF NOT EXISTS "search_cache"("id" INTEGER PRIMARY KEY AUTOINCREMENT, "hash_id" TEXT NOT NULL, "ts" TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "host" TEXT, "url" TEXT,"display" TEXT);

CREATE TABLE IF NOT EXISTS "player_state" ("playid" INTEGER  PRIMARY KEY AUTOINCREMENT, "hash" TEXT, "current" TEXT, "total" TEXT, "percent" TEXT, UNIQUE (hash) ON CONFLICT REPLACE);

CREATE TABLE IF NOT EXISTS "subscriptions" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "imdb_id" TEXT UNIQUE, "title" TEXT, "enabled" INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS  "lists" ("id" INTEGER PRIMARY KEY AUTOINCREMENT,"list" TEXT, "username" TEXT, "slug" TEXT, "media" TEXT, "sync" INTEGER DEFAULT (1), UNIQUE (username, slug, media) ON CONFLICT REPLACE);

CREATE TABLE IF NOT EXISTS "list_movies" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "list_id" INTEGER, "imdb_id" TEXT, "path" TEXT);

CREATE TABLE IF NOT EXISTS "hosts" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "host" TEXT UNIQUE, "title" TEXT, "enabled" INTEGER DEFAULT 1);

CREATE VIEW IF NOT EXISTS cache_status AS SELECT hash_id,  display, url, host, strftime('%s','now') -  strftime('%s',ts) < (3600 * 4) as "fresh" FROM search_cache
